#!/bin/bash
swaylock \
  --image ~/wallp/green.jpg \
  --scaling fill \
  --clock \
  --indicator \
  --indicator-radius 140 \
  --indicator-thickness 10 \
  --datestr "%a, %d %b" \
  --timestr "%H:%M" \
  --inside-color 00000066 \
  --ring-color 00000000 \
  --line-color 00000000 \
  --separator-color 00000000 \
  --text-color ffffff \
  -f
