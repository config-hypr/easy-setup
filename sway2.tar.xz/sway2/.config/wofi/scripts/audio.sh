#!/bin/bash

get_volume() {
  wpctl get-volume @DEFAULT_AUDIO_SINK@ | awk '{print int($2*100)}'
}

main_menu() {
  VOLUME=$(get_volume)

  printf "\
Audio Control (%s%%)\n\
Media ▶\n\
Audio ▶\n\
Mic ▶\n\
System ▶\n\
" "$VOLUME"
}

audio_menu() {
  printf "\
Volume +5%%\n\
Volume -5%%\n\
Mute Toggle\n\
Back\n"
}

media_menu() {
  printf "\
Play/Pause\n\
Next\n\
Previous\n\
Back\n"
}

mic_menu() {
  printf "\
Mic Toggle\n\
Back\n"
}

system_menu() {
  printf "\
Back\n"
}

while true; do
  CHOICE=$(main_menu | wofi --dmenu --prompt "Control Center")

  case "$CHOICE" in
    "Audio ▶")
      while true; do
        A=$(audio_menu | wofi --dmenu --prompt "Audio")
        case "$A" in
          "Volume +5%") wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+ ;;
          "Volume -5%") wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%- ;;
          "Mute Toggle") wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle ;;
          "Back") break ;;
        esac
      done
      ;;

    "Media ▶")
      while true; do
        M=$(media_menu | wofi --dmenu --prompt "Media")
        case "$M" in
          "Play/Pause") playerctl play-pause ;;
          "Next") playerctl next ;;
          "Previous") playerctl previous ;;
          "Back") break ;;
        esac
      done
      ;;

    "Mic ▶")
      while true; do
        X=$(mic_menu | wofi --dmenu --prompt "Mic")
        case "$X" in
          "Mic Toggle") wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle ;;
          "Back") break ;;
        esac
      done
      ;;

    "System ▶")
      while true; do
        S=$(system_menu | wofi --dmenu --prompt "System")
        case "$S" in
          "Back") break ;;
        esac
      done
      ;;
  esac
done
